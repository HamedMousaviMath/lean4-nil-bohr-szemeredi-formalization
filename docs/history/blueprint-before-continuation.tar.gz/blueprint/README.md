# Blueprints

`compact.tex` is the primary reading guide. `full.tex` develops the estimates and proofs in dependency order. Both include the manuscript numbering and share the catalogue of checked steps. The PDFs are `compact.pdf` and `full.pdf`.

Build both in this directory with a standard TeX Live installation containing the AMS packages, `geometry`, `hyperref`, `booktabs`, `longtable`, and TikZ.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error compact.tex full.tex
```

The source uses standard leanblueprint declaration and dependency tags. With the `leanblueprint` Python package and its Graphviz dependencies installed, render the corresponding dependency graphs with the following commands.

```sh
plastex -c plastex.cfg -d /tmp/nilbohr-compact-web web.tex
plastex -c plastex.cfg -d /tmp/nilbohr-full-web full-web.tex
```

Lean declaration names are fully qualified. An open statement can have a Lean target declaration without a proof check mark. Checked conditional deductions state their premises in the text. See [the paper map](../docs/PAPER_MAP.md), [assumption catalogue](../docs/ASSUMPTIONS.md), and [manuscript corrections](../docs/CORRECTIONS.md).
