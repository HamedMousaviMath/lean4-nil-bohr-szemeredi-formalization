import NilBohr.TwistedOrbit

/-! An explicit vertical-coordinate chain estimate toward metric separation. -/

namespace NilBohr
noncomputable section

private def scalarMalcevEdge (g h : HeisenbergPoint) : ℝ :=
  min
    (heisenbergMalcevNorm (heisenbergMul g (heisenbergInv h)))
    (heisenbergMalcevNorm (heisenbergMul h (heisenbergInv g)))

private theorem scalarMalcevEdge_y (g h : HeisenbergPoint) :
    |g.2.1 - h.2.1| ≤ scalarMalcevEdge g h := by
  have one (u v : HeisenbergPoint) :
      |u.2.1 - v.2.1| ≤ heisenbergMalcevNorm (heisenbergMul u (heisenbergInv v)) := by
    simp only [heisenbergMalcevNorm, heisenbergMul, heisenbergInv, sub_eq_add_neg]
    exact (le_max_left _ _).trans (le_max_right _ _)
  exact le_min (one g h) ((abs_sub_comm _ _).le.trans (one h g))

private theorem scalarMalcevEdge_nonneg (g h : HeisenbergPoint) : 0 ≤ scalarMalcevEdge g h :=
  (abs_nonneg _).trans (scalarMalcevEdge_y _ _)

private theorem malcev_vertical_eq (x y : HeisenbergPoint) :
    (heisenbergMul x (heisenbergInv y)).2.2 -
      (heisenbergMul x (heisenbergInv y)).1 * (heisenbergMul x (heisenbergInv y)).2.1 =
      (x.2.2 - y.2.2) - (x.1 - y.1) * x.2.1 := by
  simp only [heisenbergMul, heisenbergInv]
  ring

private theorem scalarMalcevEdge_z (g h : HeisenbergPoint) (Y : ℝ)
    (hg : |g.2.1| ≤ Y) (hh : |h.2.1| ≤ Y) :
    |g.2.2 - h.2.2| ≤ scalarMalcevEdge g h * (1 + Y) := by
  have one (u v : HeisenbergPoint) (hu : |u.2.1| ≤ Y) :
      |u.2.2 - v.2.2| ≤ (heisenbergMalcevNorm (heisenbergMul u (heisenbergInv v))) * (1 + Y) := by
    let E := heisenbergMalcevNorm (heisenbergMul u (heisenbergInv v))
    have hₓ : |u.1 - v.1| ≤ E := by
      dsimp [E, heisenbergMalcevNorm, heisenbergMul, heisenbergInv]
      exact le_max_left _ _
    have h𝓏 : |(u.2.2 - v.2.2) - (u.1 - v.1) * u.2.1| ≤ E := by
      rw [← malcev_vertical_eq]
      exact (le_max_right _ _).trans (le_max_right _ _)
    calc
      _ = |((u.2.2 - v.2.2) - (u.1 - v.1) * u.2.1) + (u.1 - v.1) * u.2.1| := by
        rw [sub_add_cancel]
      _ ≤ |(u.2.2 - v.2.2) - (u.1 - v.1) * u.2.1| + |(u.1 - v.1) * u.2.1| := by
        exact abs_add_le _ _
      _ ≤ E + E * Y := by
        rw [abs_mul]
        exact add_le_add h𝓏 (mul_le_mul hₓ hu (abs_nonneg _) ((abs_nonneg _).trans hₓ))
      _ = _ := by ring
  unfold scalarMalcevEdge
  rw [min_mul_of_nonneg _ _ (by linarith [abs_nonneg g.2.1])]
  exact le_min (one g h hg) ((abs_sub_comm _ _).le.trans (one h g hh))

/-- The total Mal'cev chain length controls the vertical coordinate
quadratically along every finite chain. -/
theorem heisenberg_chain_vertical_le (x : ℕ → HeisenbergPoint) (n : ℕ) :
    let L := ∑ i ∈ Finset.range n, scalarMalcevEdge (x i) (x (i+1))
    |(x 0).2.2 - (x n).2.2| ≤ L * (1 + |(x 0).2.1| + L) := by
  let E (i : ℕ) := scalarMalcevEdge (x i) (x (i+1))
  let L := ∑ i ∈ Finset.range n, E i
  have hY (i : ℕ) (hi : i ≤ n) : |(x i).2.1| ≤ |(x 0).2.1| + L := by
    have h1 := dist_le_range_sum_of_dist_le (f := fun j => (x j).2.1) i
      (d := E) (fun j => by
        rw [Real.dist_eq]
        exact scalarMalcevEdge_y _ _)
    rw [Real.dist_eq, abs_sub_comm] at h1
    have h2 : (∑ j ∈ Finset.range i, E j) ≤ L :=
      Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hi)
        (fun j _ _ => scalarMalcevEdge_nonneg _ _)
    calc
      _ = |(x 0).2.1 + ((x i).2.1 - (x 0).2.1)| := by congr 1; ring
      _ ≤ _ := (abs_add_le _ _).trans (add_le_add_left (h1.trans h2) _)
  calc
    |(x 0).2.2 - (x n).2.2| ≤ ∑ i ∈ Finset.range n, dist (x i).2.2 (x (i+1)).2.2 := by
      rw [← Real.dist_eq]
      exact dist_le_range_sum_dist (fun i => (x i).2.2) n
    _ ≤ ∑ i ∈ Finset.range n, E i * (1 + |(x 0).2.1| + L) := by
      apply Finset.sum_le_sum
      intro i hi
      rw [Real.dist_eq, add_assoc]
      have hin := Finset.mem_range.mp hi
      exact scalarMalcevEdge_z _ _ _ (hY i hin.le) (hY (i+1) hin)
    _ = L * (1 + |(x 0).2.1| + L) := by rw [← Finset.sum_mul]

private theorem scalarMalcevEdge_x (g h : HeisenbergPoint) :
    |g.1 - h.1| ≤ scalarMalcevEdge g h := by
  have one (u v : HeisenbergPoint) :
      |u.1 - v.1| ≤ heisenbergMalcevNorm (heisenbergMul u (heisenbergInv v)) := by
    simp only [heisenbergMalcevNorm, heisenbergMul, heisenbergInv, sub_eq_add_neg]
    exact le_max_left _ _
  exact le_min (one g h) ((abs_sub_comm _ _).le.trans (one h g))

private def scalarChainLengths (g h : HeisenbergPoint) : Set ℝ :=
  {d | ∃ (n : ℕ) (x : ℕ → HeisenbergPoint), x 0 = g ∧ x n = h ∧
    d = ∑ i ∈ Finset.range n, scalarMalcevEdge (x i) (x (i+1))}

private theorem scalarChainLengths_nonempty (g h : HeisenbergPoint) :
    (scalarChainLengths g h).Nonempty :=
  ⟨_, 1, fun i => if i = 0 then g else h, by simp, by simp, rfl⟩

private theorem scalarChainLengths_bddBelow (g h : HeisenbergPoint) :
    BddBelow (scalarChainLengths g h) := by
  refine ⟨0, ?_⟩
  rintro _ ⟨n, x, _, _, rfl⟩
  exact Finset.sum_nonneg (fun _ _ => scalarMalcevEdge_nonneg _ _)

theorem heisenbergGroupDistance_eq_zero_iff (g h : HeisenbergPoint) :
    heisenbergGroupDistance g h = 0 ↔ g = h := by
  refine ⟨?_, ?_⟩
  · intro hg
    have hsmall (ε : ℝ) (hε : 0 < ε) :
        ∃ t ∈ scalarChainLengths g h, t < ε := by
      apply exists_lt_of_csInf_lt (scalarChainLengths_nonempty g h)
      change heisenbergGroupDistance g h < ε
      rwa [hg]
    have horizontal (f : HeisenbergPoint → ℝ)
        (he : ∀ p q, |f p - f q| ≤ scalarMalcevEdge p q) : f g = f h := by
      by_contra hne
      have habs : 0 < |f g - f h| := abs_pos.mpr (sub_ne_zero.mpr hne)
      obtain ⟨t, ⟨n, x, hx, hy, rfl⟩, ht⟩ := hsmall _ habs
      rw [← hx, ← hy] at ht
      refine (not_lt_of_ge ?_) ht
      rw [← Real.dist_eq]
      exact dist_le_range_sum_of_dist_le (f := fun i => f (x i)) n (fun _ => by
        rw [Real.dist_eq]
        exact he _ _)
    have hz : g.2.2 = h.2.2 := by
      by_contra hne
      let C := 2 + |g.2.1|
      let d := |g.2.2 - h.2.2|
      have hd : 0 < d := abs_pos.mpr (sub_ne_zero.mpr hne)
      have hC : 0 < C := by dsimp [C]; positivity
      obtain ⟨t, ⟨n, x, hx, hy, rfl⟩, ht⟩ :=
        hsmall (min 1 (d/C)) (lt_min zero_lt_one (div_pos hd hC))
      let L := ∑ i ∈ Finset.range n, scalarMalcevEdge (x i) (x (i+1))
      have hL : 0 ≤ L := Finset.sum_nonneg (fun _ _ => scalarMalcevEdge_nonneg _ _)
      have hLt : L < 1 := ht.trans_le (min_le_left _ _)
      have hLd : L * C < d := (lt_div_iff₀ hC).mp (ht.trans_le (min_le_right _ _))
      have hv := heisenberg_chain_vertical_le x n
      change |(x 0).2.2 - (x n).2.2| ≤ L * (1 + |(x 0).2.1| + L) at hv
      rw [hx, hy] at hv
      have hLC : 1 + |g.2.1| + L ≤ C := by dsimp [C]; linarith only [hLt]
      exact (not_lt_of_ge (hv.trans (mul_le_mul_of_nonneg_left hLC hL))) hLd
    exact Prod.ext (horizontal Prod.fst scalarMalcevEdge_x) <|
      Prod.ext (horizontal (fun p => p.2.1) scalarMalcevEdge_y) hz
  · rintro rfl
    change sInf (scalarChainLengths g g) = 0
    refine le_antisymm (csInf_le (scalarChainLengths_bddBelow _ _)
      ⟨0, fun _ => g, rfl, rfl, by simp⟩) ?_
    apply le_csInf (scalarChainLengths_nonempty _ _)
    rintro _ ⟨n, x, _, _, rfl⟩
    exact Finset.sum_nonneg (fun _ _ => scalarMalcevEdge_nonneg _ _)

end
end NilBohr
