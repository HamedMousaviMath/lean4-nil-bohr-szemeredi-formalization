# Follow-up Green–Tao certificates

These three modules are follow-up work outside the production import graph and the current manuscript statement coverage. Each can be checked against this project's pinned Lean and Mathlib versions once the production library builds. Extract this archive to a scratch directory, then run `lake env lean /path/to/scratch/File.lean` from the project root for each source.

- `GreenTaoScalarSeparation.lean` gives an explicit vertical bound along every finite Mal’cev chain and deduces that zero group distance implies equality.
- `GreenTaoHaarAmbient.lean` proves that ambient Lebesgue measure in matrix coordinates is bi-invariant Haar, checks covolume one, and identifies the scalar quotient measure with Haar restricted to a fundamental domain and then pushed down.
- `GreenTaoContinuous.lean` shows that the manuscript's scalar tests descend continuously to the ordinary topological coset quotient and have the exact chart integral.

The next step is to finish the metric on the coset quotient and prove compatibility with its existing topology. The adapted rational Lie basis, product quotient and final specialization of the quantitative Leibman theorem remain separate tasks.
